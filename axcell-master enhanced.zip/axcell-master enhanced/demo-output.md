```
Building prefix dict from the default dictionary ...
Loading model from cache /var/folders/jr/qgh_hd1945bb_g0k8fwy_gn00000gp/T/jieba.cache
Loading model cost 0.757 seconds.
Prefix dict has been built succesfully.
float division by zero
setting textrank_keywords to empty
tfidf: precision=0.350000000000375, recall=0.4179104477614391, f1-score=0.38095238095270495
In article 1, keywords are:  融合, 军民, 发展, 中央, 委员会, 深度, 习近平, 强化, 加快, 建设
In article 2, keywords are:  航母, 003, 弹射, 战斗机, 歼, 舰载, 型, 推进, 核动力, 下一代
In article 3, keywords are:  无人机, 伊朗, 击落, 战机, 一架, 叙利亚, 美军, 制, 该架, 巴基斯坦
In article 4, keywords are:  民进党, 大陆, 僵局, 卡, 两岸, 你, 台南市, 错, 台湾, 网友
In article 5, keywords are:  澳大利亚, 澳, 中国, 提案, 澳媒, 澳洲, 毕晓普, 印度洋, 对象, 布尔
In article 6, keywords are:  女儿, 律师, 阿姨, 张, 王女士, 丈夫, 刘先生, 周勇, 咨询, 法院
In article 7, keywords are:  李光耀, 新加坡, 故居, 显扬, 李, 李显龙, 声明, 父亲, 弟弟, 李玮玲
In article 8, keywords are:  辽宁, 舰, 香港, 航母, 开放, 军舰, 台湾海峡, 香港市民, 环球时报, 海军
In article 9, keywords are:  兰溪, 奚金燕, 图为, 水位, 钱塘江, 汛情, 流域, 严防死守, 协力, 堆
In article 10, keywords are:  巴特, 蒙古国, 候选人, 蒙古, 托勒嘎, 包勒德, 恩赫, 竞选, 大呼拉尔, 宣传
In article 11, keywords are:  复兴号, 动车组, 标准, 高铁, 列车, 知识产权, 速度, 中国, 自主, 总公司
In article 12, keywords are:  刘洪斌, 广告, 神医, 中医, 播出, 违规, 中医药, 传人, 国家中医药管理局, 工商总局
In article 13, keywords are:  发言人, 长臂, 管辖, 外交部, 中方, 　, 新词, 美国, 中国外交部, 耿爽
In article 14, keywords are:  高猛, 亲人, 垮塌, 遇难, 救援, 现场, 新磨村, 舅妈, 舅舅, 电话
In article 15, keywords are:  群众, 安源, 搜救, 灾害, 名, 确认, 受灾, 心理, 消防官兵, 灾区
In article 16, keywords are:  变革, 革命, 研究, 李克强, 科学家, 科技, 产业, 总理, 院士, 机遇
In article 17, keywords are:  治国, 理政, 习近平, 谈, 中国, 世界, …, 　, 道路, 梦想
In article 18, keywords are:  总书记, 考察, 习近平, 山西, 主席, 中共中央, 中央军委, 调研, 来到, 新华社
In article 19, keywords are:  徐晓冬, 切磋, 太极, 比赛, 民警, 您, 被迫, 说道, 配合, 这场
In article 20, keywords are:  两岸, 经贸, 交流, 台湾, 官方, 蔡, 产业, 协会, 连续, 下滑
tfidf with span: precision=0.36250000000034377, recall=0.43283582089572287, f1-score=0.39455782312953863
In article 1, keywords are:  融合, 军民, 发展, 中央, 委员会, 深度, 习近平, 强化, 建设, 加快
In article 2, keywords are:  航母, 003, 弹射, 舰载, 推进, 战斗机, 我国, 下一代, 建造, 海军
In article 3, keywords are:  无人机, 伊朗, 击落, 战机, 一架, 叙利亚, 美军, 该架, 境内, 巴基斯坦
In article 4, keywords are:  民进党, 大陆, 僵局, 两岸, 台南市, 台湾, 网友, 中国, 问题, 19
In article 5, keywords are:  澳大利亚, 中国, 提案, 澳洲, 澳媒, 布尔, 特恩, 毕晓普, 担忧, 对象
In article 6, keywords are:  女儿, 律师, 阿姨, 王女士, 丈夫, 刘先生, 咨询, 法院, 周勇, 事务所
In article 7, keywords are:  李光耀, 新加坡, 故居, 显扬, 李显龙, 父亲, 声明, 弟弟, 李玮玲, 欧思礼路
In article 8, keywords are:  辽宁, 香港, 航母, 开放, 台湾海峡, 香港市民, 军舰, 环球时报, 海军, 访港
In article 9, keywords are:  兰溪, 奚金燕, 图为, 钱塘江, 水位, 流域, 浙江省, 汛情, 洪水, 防汛
In article 10, keywords are:  蒙古国, 巴特, 蒙古, 候选人, 托勒嘎, 包勒德, 恩赫, 竞选, 选举, 巴特尔
In article 11, keywords are:  复兴号, 动车组, 标准, 高铁, 列车, 知识产权, 中国, 速度, 自主, 总公司
In article 12, keywords are:  刘洪斌, 广告, 神医, 中医, 播出, 违规, 传人, 专家, 中医药, 医药
In article 13, keywords are:  发言人, 长臂, 管辖, 外交部, 中方, 新词, 中国外交部, 美国, 耿爽, 网友
In article 14, keywords are:  高猛, 亲人, 垮塌, 遇难, 救援, 现场, 新磨村, 舅妈, 遗体, 希望
In article 15, keywords are:  群众, 灾害, 安源, 搜救, 设立, 心理, 灾区, 10, 14, 确认
In article 16, keywords are:  变革, 革命, 研究, 李克强, 科学家, 科技, 产业, 总理, 院士, 量子
In article 17, keywords are:  治国, 理政, 习近平, 中国, 世界, 道路, 合作, 关于, 泰国, 梦想
In article 18, keywords are:  总书记, 考察, 习近平, 山西, 主席, 中共中央, 中央军委, 来到, 调研, 新华社
In article 19, keywords are:  徐晓冬, 切磋, 比赛, 民警, 太极, 这场, 现场, 被迫, 说道, 配合
In article 20, keywords are:  两岸, 经贸, 交流, 台湾, 官方, 产业, 协会, 显示, 下滑, 不少
textrank: precision=0.14285714285816326, recall=0.14925373134433056, f1-score=0.1459854014608876
In article 1, keywords are:  习近平, 委员会, 中共中央总书记, 刘云山出席会议, 负责同志列席会议, 第一次全体会议, 只争朝夕, 党中央, 贯彻落实, 紧迫感
In article 2, keywords are:  acpr小型化第三代, 第四代战斗机, 改进型不足以, 大中型航空母舰, 核动力, 众所周知, 中广核, 核反应堆
In article 3, keywords are:  叙利亚, 无人机, 巴基斯坦, 地面部队构成威胁, 政府军, 反抗军, 环球网, 美国有线电视新闻网, 俾路支省, 国防部
In article 4, keywords are:  台湾地区, 领导人
In article 5, keywords are:  澳大利亚, 澳大利亚广播公司, 委员会, 执政党自由党, 郭春梅, 印度洋, 西北部, 焦虑症, 研究院南太平洋研究室, 一方面在经济上
In article 6, keywords are:  刘先生, 事务所, 王女士, 琚晓奇, 共同财产, 仇珊珊
In article 7, keywords are:  李光耀, 新加坡, 李玮玲, 欧思礼路, 脸书以
In article 8, keywords are:  国防部, 台湾当局, 亚丁湾, 香港市民, 访问期间, 索马里, 昂船洲海军基地, 年龄段, 自豪感, 认同感
In article 9, keywords are:  万平方米, 钱塘江, 警戒水位, 浙江省, 防汛防台, 古城墙奚金燕, 彩布条, 土工布
In article 10, keywords are:  候选人, 人民党, 蒙古国特派记者, 爱国者, 托勒嘎以, 第七次总统大选, 无所适从, 一会儿, 万韩元, 统一教
In article 11, keywords are:  复兴号, 动车组, 总公司, 总工程师, 长距离, 高强度, 监测点全方位, 行业标准, 国家标准, 最新版
In article 12, keywords are:  王志金, 国家中医药管理局, 刘洪斌, 新闻出版广电总局, 高振宗, 李志明
In article 13, keywords are:  外交部发言人, arm, long, 中国外交部, 选择性失忆症, bbc中文网, 中国人民大学国际关系学院, 华春莹, jurisdiction, 管辖权
In article 14, keywords are:  救援车辆, 维持秩序
In article 15, keywords are:  社会各界信息反馈, 抢险救灾第五场
In article 16, keywords are:  潘建伟, 潘云鹤, 中新社盛佳鹏, 李克强, 中国科学院, 生产力, 顶尖人物, 深刻影响, 中国工程院, 人工智能
In article 17, keywords are:  世界银行, 习近平, 方略图, 布雷斯, 恐怖袭击此起彼伏, 新一轮深化改革, 参议院国防委员会, 说到做到, 新一代领导人, 只争朝夕
In article 18, keywords are:  习近平总书记, 新华社, 迎头赶上, 老同志, 老战士, 奋起直追, 中央政治局常委, 中央书记处, 忻州市岢岚县, 刘福有
In article 19, keywords are:  
In article 20, keywords are:  近一半观光业, 董事长卓文财, 精密机械制造商, 书同文, 车同轨
```
